﻿namespace Health.Core;

public class Class1
{

}
