[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "HealthMaui")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "HealthMaui.Pages")]
