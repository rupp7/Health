namespace HealthMaui.Pages;

public partial class TestPage : ContentPage
{
    public TestPage()
    {
        InitializeComponent();
    }
}